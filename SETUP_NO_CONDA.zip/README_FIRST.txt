EmoAtlas Windows venv installer (no Conda/Miniconda)
=====================================================

1. Read EMOATLAS_WINDOWS_VENV_GUIDE.md.
2. Install 64-bit Python 3.11.9 with pip and the Python launcher.
3. Open a terminal in this folder (Command Prompt or PowerShell).
4. Run one of the setup commands below, using the syntax for your shell.

Command Prompt (CMD)
--------------------

   setup_emoatlas_venv.bat
   setup_emoatlas_venv.bat --italian
   setup_emoatlas_venv.bat --both
   setup_emoatlas_venv.bat --no-jupyter

Managed rebuild:
   setup_emoatlas_venv.bat --recreate

Managed removal:
   setup_emoatlas_venv.bat --remove

PowerShell
----------

PowerShell does not run scripts from the current folder unless the
command is preceded by .\ (dot backslash). The same commands become:

   .\setup_emoatlas_venv.bat
   .\setup_emoatlas_venv.bat --italian
   .\setup_emoatlas_venv.bat --both
   .\setup_emoatlas_venv.bat --no-jupyter

Managed rebuild:
   .\setup_emoatlas_venv.bat --recreate

Managed removal:
   .\setup_emoatlas_venv.bat --remove

If you type the command without .\ in PowerShell, you will get an
error such as:

   setup_emoatlas_venv.bat : The term 'setup_emoatlas_venv.bat' is not
   recognized as the name of a cmdlet, function, script file, or
   operable program.

This is expected PowerShell behaviour, not a problem with the
installer. Add .\ and run the command again.

Installation location
---------------------

The managed installation defaults to:
   %LOCALAPPDATA%\EmoAtlas\venv

The detailed guide covers removal of older Conda environments, manual
virtual environments, global/user pip installs, editable clones,
Jupyter kernels, NLTK data, PATH entries, environment variables, and
caches.
