@echo off
setlocal EnableExtensions DisableDelayedExpansion
title EmoAtlas Windows venv installer

rem ============================================================================
rem EmoAtlas installer for Windows using Python's built-in venv (NO CONDA).
rem
rem Default installation directory:
rem   %LOCALAPPDATA%\EmoAtlas\venv
rem
rem Usage:
rem   setup_emoatlas_venv.bat
rem   setup_emoatlas_venv.bat --italian
rem   setup_emoatlas_venv.bat --both
rem   setup_emoatlas_venv.bat --no-jupyter
rem   setup_emoatlas_venv.bat --recreate
rem   setup_emoatlas_venv.bat --remove
rem   setup_emoatlas_venv.bat --help
rem
rem Optional environment-variable override before running:
rem   set "EMOATLAS_HOME=D:\Applications\EmoAtlas"
rem ============================================================================

if not defined LOCALAPPDATA set "LOCALAPPDATA=%USERPROFILE%\AppData\Local"

if defined EMOATLAS_HOME (
    set "EMOATLAS_HOME_DIR=%EMOATLAS_HOME%"
) else (
    set "EMOATLAS_HOME_DIR=%LOCALAPPDATA%\EmoAtlas"
)

set "VENV_DIR=%EMOATLAS_HOME_DIR%\venv"
set "VENV_PYTHON=%VENV_DIR%\Scripts\python.exe"
set "JUPYTER_EXE=%VENV_DIR%\Scripts\jupyter.exe"
set "NLTK_DATA_DIR=%VENV_DIR%\nltk_data"
set "KERNEL_NAME=emoatlas311-venv"
if not defined EMOATLAS_ZIP_URL set "EMOATLAS_ZIP_URL=https://github.com/MassimoStel/emoatlas/archive/refs/heads/main.zip"
set "SOURCE_STAGE=%TEMP%\emoatlas-venv-installer-%RANDOM%-%RANDOM%"
set "SOURCE_DIR="
set "BASE_PYTHON="

set "INSTALL_ENGLISH=1"
set "INSTALL_ITALIAN=0"
set "INSTALL_JUPYTER=1"
set "RECREATE=0"
set "REMOVE_ONLY=0"
set "PAUSE_AT_END=1"

:parse_args
if "%~1"=="" goto args_done
if /I "%~1"=="--english" (
    set "INSTALL_ENGLISH=1"
    set "INSTALL_ITALIAN=0"
    shift
    goto parse_args
)
if /I "%~1"=="--italian" (
    set "INSTALL_ENGLISH=0"
    set "INSTALL_ITALIAN=1"
    shift
    goto parse_args
)
if /I "%~1"=="--both" (
    set "INSTALL_ENGLISH=1"
    set "INSTALL_ITALIAN=1"
    shift
    goto parse_args
)
if /I "%~1"=="--no-jupyter" (
    set "INSTALL_JUPYTER=0"
    shift
    goto parse_args
)
if /I "%~1"=="--recreate" (
    set "RECREATE=1"
    shift
    goto parse_args
)
if /I "%~1"=="--remove" (
    set "REMOVE_ONLY=1"
    shift
    goto parse_args
)
if /I "%~1"=="--no-pause" (
    set "PAUSE_AT_END=0"
    shift
    goto parse_args
)
if /I "%~1"=="--help" goto print_help
if /I "%~1"=="-h" goto print_help

echo.
echo ERROR: Unknown option: %~1
echo Run "%~nx0 --help" for valid options.
goto fail

:args_done
echo.
echo ============================================================================
echo  EmoAtlas Windows installer - isolated Python 3.11 virtual environment
echo  No Conda or Miniconda is used.
echo ============================================================================
echo.
echo Installation home: "%EMOATLAS_HOME_DIR%"
echo Virtual environment: "%VENV_DIR%"
echo.

if "%REMOVE_ONLY%"=="1" goto remove_installation

call :find_python311
if not defined BASE_PYTHON goto python_not_found

echo Found compatible Python:
"%BASE_PYTHON%" --version
echo Interpreter:
echo   "%BASE_PYTHON%"
echo.

if "%RECREATE%"=="1" (
    echo Recreate requested. Removing the installer-managed environment first...
    call :remove_managed_kernel
    if exist "%VENV_DIR%" rmdir /S /Q "%VENV_DIR%"
    if exist "%VENV_DIR%" (
        echo ERROR: Could not remove "%VENV_DIR%".
        echo Close Python, Jupyter, editors, and terminals using that environment, then retry.
        goto fail
    )
)

if exist "%VENV_PYTHON%" goto validate_existing_venv
if exist "%VENV_DIR%" (
    echo ERROR: "%VENV_DIR%" exists but is not a usable Python virtual environment.
    echo Rename/remove that directory, or rerun with --recreate.
    goto fail
)

echo [1/9] Creating Python 3.11 virtual environment...
if not exist "%EMOATLAS_HOME_DIR%" mkdir "%EMOATLAS_HOME_DIR%"
"%BASE_PYTHON%" -m venv "%VENV_DIR%"
if errorlevel 1 (
    echo ERROR: Python could not create the virtual environment.
    goto fail
)
goto venv_ready

:validate_existing_venv
echo [1/9] Reusing the existing virtual environment...
"%VENV_PYTHON%" -c "import platform,sys; ok=(sys.version_info[:2]==(3,11) and sys.maxsize>2**32 and platform.python_implementation()=='CPython'); raise SystemExit(0 if ok else 1)" >nul 2>&1
if errorlevel 1 (
    echo ERROR: The existing environment is not Python 3.11.
    echo Rerun with --recreate to replace it safely.
    goto fail
)

:venv_ready
set "NLTK_DATA=%NLTK_DATA_DIR%"

if not exist "%VENV_PYTHON%" (
    echo ERROR: The venv Python executable was not created.
    goto fail
)

"%VENV_PYTHON%" -m ensurepip --upgrade >nul 2>&1
if errorlevel 1 (
    echo ERROR: pip could not be bootstrapped in the virtual environment.
    goto fail
)

echo [2/9] Updating pip, setuptools, and wheel...
"%VENV_PYTHON%" -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto pip_failure

echo [3/9] Installing EmoAtlas runtime dependencies...
rem The repository currently lists both "community" and "python-louvain".
rem EmoAtlas imports community.community_louvain, which is provided by
rem python-louvain. The unrelated "community" distribution is intentionally
rem removed/omitted to avoid a namespace collision.
"%VENV_PYTHON%" -m pip uninstall -y community >nul 2>&1
"%VENV_PYTHON%" -m pip install --upgrade --prefer-binary ^
    matplotlib ^
    spacy ^
    networkx ^
    nltk ^
    "shapely>=2.0.1" ^
    pandas ^
    numpy ^
    scipy ^
    chardet ^
    deep-translator ^
    simplemma
if errorlevel 1 goto pip_failure

"%VENV_PYTHON%" -m pip install --upgrade --force-reinstall --prefer-binary python-louvain
if errorlevel 1 goto pip_failure

echo [4/9] Downloading a temporary copy of EmoAtlas source...
if exist "%SOURCE_STAGE%" rmdir /S /Q "%SOURCE_STAGE%"
"%VENV_PYTHON%" -c "import io,pathlib,shutil,urllib.request,zipfile; d=pathlib.Path(r'''%SOURCE_STAGE%'''); shutil.rmtree(d,ignore_errors=True); d.mkdir(parents=True); data=urllib.request.urlopen(r'''%EMOATLAS_ZIP_URL%''',timeout=180).read(); zipfile.ZipFile(io.BytesIO(data)).extractall(d)"
if errorlevel 1 (
    echo ERROR: Could not download or extract EmoAtlas from GitHub.
    echo Check the internet connection, proxy, firewall, and TLS inspection settings.
    goto fail
)

for /D %%D in ("%SOURCE_STAGE%\emoatlas-*") do set "SOURCE_DIR=%%~fD"
if not defined SOURCE_DIR (
    echo ERROR: The downloaded archive did not contain the expected source directory.
    goto fail
)
if not exist "%SOURCE_DIR%\requirements.txt" (
    echo ERROR: The downloaded repository is missing requirements.txt.
    goto fail
)

rem Normalize two repository packaging details in the temporary copy only:
rem   1. Remove the unrelated, bare "community" requirement.
rem   2. Explicitly include valence/* as package data. A GitHub ZIP has no .git
rem      metadata for setuptools-scm's file finder, while EmoAtlas imports these
rem      modules at runtime. The upstream repository itself is never modified.
"%VENV_PYTHON%" -c "from pathlib import Path; p=Path(r'''%SOURCE_DIR%\requirements.txt'''); rows=p.read_text(encoding='utf-8').splitlines(); p.write_text('\n'.join(x for x in rows if x.strip().lower()!='community')+'\n',encoding='utf-8')"
if errorlevel 1 (
    echo ERROR: Could not normalize the temporary requirements file.
    goto fail
)

"%VENV_PYTHON%" -c "from pathlib import Path; p=Path(r'''%SOURCE_DIR%\setup.cfg'''); s=p.read_text(encoding='utf-8'); old='emoatlas = langs/*, baseline_tables/*, antonyms/*'; assert ('valence/*' in s or old in s), 'unexpected package_data layout'; s=s if 'valence/*' in s else s.replace(old,old+', valence/*',1); p.write_text(s,encoding='utf-8')"
if errorlevel 1 (
    echo ERROR: Could not ensure that EmoAtlas valence modules are packaged.
    goto fail
)

echo [5/9] Installing EmoAtlas from the normalized temporary source copy...
"%VENV_PYTHON%" -m pip install --upgrade --force-reinstall --no-deps "%SOURCE_DIR%"
if errorlevel 1 goto pip_failure
call :cleanup_source

echo [6/9] Installing selected spaCy language model(s)...
if "%INSTALL_ENGLISH%"=="1" (
    echo Installing en_core_web_lg...
    "%VENV_PYTHON%" -m spacy download en_core_web_lg
    if errorlevel 1 (
        echo ERROR: spaCy could not install en_core_web_lg.
        goto fail
    )
)
if "%INSTALL_ITALIAN%"=="1" (
    echo Installing it_core_news_lg...
    "%VENV_PYTHON%" -m spacy download it_core_news_lg
    if errorlevel 1 (
        echo ERROR: spaCy could not install it_core_news_lg.
        goto fail
    )
)

echo [7/9] Installing NLTK data inside the virtual environment...
if not exist "%NLTK_DATA_DIR%" mkdir "%NLTK_DATA_DIR%"
"%VENV_PYTHON%" -m nltk.downloader -d "%NLTK_DATA_DIR%" wordnet omw-1.4 punkt punkt_tab
if errorlevel 1 (
    echo ERROR: NLTK data download failed.
    goto fail
)

if "%INSTALL_JUPYTER%"=="1" goto install_jupyter
echo [8/9] Jupyter installation skipped by --no-jupyter.
if exist "%EMOATLAS_HOME_DIR%\start_emoatlas_jupyterlab.bat" del /F /Q "%EMOATLAS_HOME_DIR%\start_emoatlas_jupyterlab.bat"
goto create_helpers

:install_jupyter
echo [8/9] Installing JupyterLab, Notebook, and an isolated kernel...
"%VENV_PYTHON%" -m pip install --upgrade ipykernel jupyterlab notebook
if errorlevel 1 goto pip_failure
call :remove_managed_kernel
"%VENV_PYTHON%" -m ipykernel install --user --name "%KERNEL_NAME%" --display-name "Python (EmoAtlas venv 3.11)"
if errorlevel 1 (
    echo ERROR: The Jupyter kernel could not be registered.
    goto fail
)

:create_helpers
echo [9/9] Creating launch helpers and validating the installation...
if not exist "%EMOATLAS_HOME_DIR%" mkdir "%EMOATLAS_HOME_DIR%"

> "%EMOATLAS_HOME_DIR%\activate_emoatlas.bat" (
    echo @echo off
    echo set "NLTK_DATA=%NLTK_DATA_DIR%"
    echo call "%VENV_DIR%\Scripts\activate.bat"
    echo echo EmoAtlas virtual environment activated.
)

if "%INSTALL_JUPYTER%"=="1" (
    > "%EMOATLAS_HOME_DIR%\start_emoatlas_jupyterlab.bat" (
        echo @echo off
        echo set "NLTK_DATA=%NLTK_DATA_DIR%"
        echo "%VENV_PYTHON%" -m jupyterlab
    )
)

"%VENV_PYTHON%" -m pip check
if errorlevel 1 (
    echo ERROR: pip detected an inconsistent dependency set.
    goto fail
)

"%VENV_PYTHON%" -c "import sys,emoatlas,simplemma; import community.community_louvain; from emoatlas.resources import _valences; from nltk.corpus import wordnet as wn; assert wn.synsets('trust'); assert len(_valences('english'))==3 and len(_valences('italian'))==3; print('EmoAtlas',getattr(emoatlas,'__version__','unknown'),'on Python',sys.version.split()[0])"
if errorlevel 1 (
    echo ERROR: EmoAtlas, valence resources, python-louvain, simplemma, or NLTK verification failed.
    goto fail
)

if "%INSTALL_ENGLISH%"=="1" (
    "%VENV_PYTHON%" -c "import spacy; from emoatlas import EmoScores; nlp=spacy.load('en_core_web_lg'); assert nlp.lang=='en'; scores=EmoScores(language='english',spacy_model='en_core_web_lg').emotions('happy trust'); assert 'joy' in scores and 'trust' in scores; print('English model and EmoScores smoke test verified')"
    if errorlevel 1 (
        echo ERROR: English spaCy model or EmoScores smoke-test verification failed.
        goto fail
    )
)
if "%INSTALL_ITALIAN%"=="1" (
    "%VENV_PYTHON%" -c "import spacy; from emoatlas import EmoScores; nlp=spacy.load('it_core_news_lg'); assert nlp.lang=='it'; scores=EmoScores(language='italian',spacy_model='it_core_news_lg').emotions('felice fiducia'); assert 'joy' in scores and 'trust' in scores; print('Italian model and EmoScores smoke test verified')"
    if errorlevel 1 (
        echo ERROR: Italian spaCy model or EmoScores smoke-test verification failed.
        goto fail
    )
)

echo.
echo ============================================================================
echo  EmoAtlas installation completed successfully.
echo ============================================================================
echo.
echo Activate from Command Prompt:
echo   call "%EMOATLAS_HOME_DIR%\activate_emoatlas.bat"
echo.
echo Or run Python directly without activation:
echo   "%VENV_PYTHON%"
echo.
if "%INSTALL_JUPYTER%"=="1" (
    echo Start JupyterLab:
    echo   "%EMOATLAS_HOME_DIR%\start_emoatlas_jupyterlab.bat"
    echo.
    echo Jupyter kernel:
    echo   Python ^(EmoAtlas venv 3.11^)
    echo.
)
echo To update this managed installation, run this installer again.
echo To rebuild it from scratch, run with --recreate.
echo To remove it, run with --remove.
echo.
call :maybe_pause
exit /B 0

:remove_installation
echo Removing the installer-managed EmoAtlas installation...
call :remove_managed_kernel
if exist "%VENV_DIR%" rmdir /S /Q "%VENV_DIR%"
if exist "%VENV_DIR%" (
    echo ERROR: Could not remove "%VENV_DIR%".
    echo Close Python, Jupyter, editors, and terminals using it, then retry.
    goto fail
)
if exist "%EMOATLAS_HOME_DIR%\activate_emoatlas.bat" del /F /Q "%EMOATLAS_HOME_DIR%\activate_emoatlas.bat"
if exist "%EMOATLAS_HOME_DIR%\start_emoatlas_jupyterlab.bat" del /F /Q "%EMOATLAS_HOME_DIR%\start_emoatlas_jupyterlab.bat"
rmdir "%EMOATLAS_HOME_DIR%" >nul 2>&1

echo.
echo The installer-managed venv, local NLTK data, helpers, and kernel were removed.
echo Other historical Conda, global pip, editable, or manually created venv
echo installations are intentionally not deleted automatically. See the supplied guide.
echo.
call :maybe_pause
exit /B 0

:find_python311
set "BASE_PYTHON="
where py >nul 2>&1
if errorlevel 1 goto try_python_on_path
for /F "usebackq delims=" %%P in (`py -3.11 -c "import sys; print(sys.executable)" 2^>nul`) do set "BASE_PYTHON=%%P"
if not defined BASE_PYTHON goto try_python_on_path
"%BASE_PYTHON%" -c "import platform,sys; ok=(sys.version_info[:2]==(3,11) and sys.maxsize>2**32 and platform.python_implementation()=='CPython'); raise SystemExit(0 if ok else 1)" >nul 2>&1
if errorlevel 1 set "BASE_PYTHON="
if defined BASE_PYTHON exit /B 0

:try_python_on_path
where python >nul 2>&1
if errorlevel 1 exit /B 0
for /F "usebackq delims=" %%P in (`python -c "import sys; print(sys.executable)" 2^>nul`) do set "BASE_PYTHON=%%P"
if not defined BASE_PYTHON exit /B 0
"%BASE_PYTHON%" -c "import platform,sys; ok=(sys.version_info[:2]==(3,11) and sys.maxsize>2**32 and platform.python_implementation()=='CPython'); raise SystemExit(0 if ok else 1)" >nul 2>&1
if errorlevel 1 set "BASE_PYTHON="
exit /B 0

:remove_managed_kernel
if exist "%JUPYTER_EXE%" "%JUPYTER_EXE%" kernelspec remove -f "%KERNEL_NAME%" >nul 2>&1
if defined APPDATA if exist "%APPDATA%\jupyter\kernels\%KERNEL_NAME%" rmdir /S /Q "%APPDATA%\jupyter\kernels\%KERNEL_NAME%"
exit /B 0

:cleanup_source
if defined SOURCE_STAGE if exist "%SOURCE_STAGE%" rmdir /S /Q "%SOURCE_STAGE%"
set "SOURCE_DIR="
exit /B 0

:python_not_found
echo ERROR: A native 64-bit Python 3.11 installation was not found.
echo.
echo EmoAtlas currently declares Python versions from 3.8 up to, but not including,
echo 3.12. This installer deliberately uses Python 3.11 to match the repository's
echo own Windows installer and maximize availability of compatible binary wheels.
echo.
echo Install Python 3.11.9 for Windows (64-bit) from python.org, including pip and
echo the Python launcher, then rerun this file:
echo   https://www.python.org/downloads/release/python-3119/
echo.
goto fail

:pip_failure
echo ERROR: A pip installation command failed.
echo Review the first error above. Common causes are a proxy/firewall, insufficient
echo disk space, antivirus file locking, or a temporarily unavailable package index.
goto fail

:print_help
echo.
echo EmoAtlas venv installer - options
echo.
echo   --english       Install the English large spaCy model. This is the default.
echo   --italian       Install the Italian large spaCy model instead of English.
echo   --both          Install both English and Italian large spaCy models.
echo   --no-jupyter    Do not install JupyterLab, Notebook, or a Jupyter kernel.
echo   --recreate      Delete and rebuild only this installer's managed venv.
echo   --remove        Remove only this installer's managed venv and kernel.
echo   --no-pause      Do not wait for a keypress before exiting.
echo   --help, -h      Show this help.
echo.
echo Default home:
echo   %LOCALAPPDATA%\EmoAtlas
echo.
echo Optional custom home (set before running):
echo   set "EMOATLAS_HOME=D:\Applications\EmoAtlas"
echo   "%~nx0" --both
echo.
exit /B 0

:fail
call :cleanup_source
echo.
echo Installation did not complete successfully.
echo No system Python packages were modified; all attempted package installation was
echo confined to "%VENV_DIR%".
echo Rerun with --recreate after correcting the reported problem.
echo.
call :maybe_pause
exit /B 1

:maybe_pause
if "%PAUSE_AT_END%"=="1" (
    echo Press any key to close this window...
    pause >nul
)
exit /B 0
