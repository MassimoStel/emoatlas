# EmoAtlas on Windows without Conda

This package contains a Windows batch installer that creates a self-contained Python 3.11 virtual environment with the standard-library `venv` module. It does **not** use Conda or Miniconda, does not require administrator rights for the default location, and does not modify the system Python's package set.

## Files

- `setup_emoatlas_venv.bat` — installer, updater, repair/recreate command, and managed uninstaller.
- This guide — installation choices, verification, and thorough cleanup of older installations.

## What the installer does

1. Finds an exact Python 3.11 interpreter, preferring the Windows `py` launcher.
2. Creates `%LOCALAPPDATA%\EmoAtlas\venv` with `python -m venv`.
3. Upgrades `pip`, `setuptools`, and `wheel` inside that environment.
4. Installs EmoAtlas runtime dependencies in the isolated environment.
5. Downloads the current `main` branch as a ZIP, so Git is not required.
6. Removes one problematic dependency declaration from a **temporary source copy only**: the bare `community` distribution. EmoAtlas imports `community.community_louvain`, which is supplied by `python-louvain`; the similarly named `community` project is unrelated.
7. Adds `valence/*` to explicit package data in the same temporary copy. EmoAtlas imports `emoatlas.valence.*`, but the current `setup.cfg` does not list that directory. This matters for a GitHub ZIP because it has no `.git` metadata for the `setuptools-scm` file finder. The original repository is not changed.
8. Installs EmoAtlas from that normalized temporary source copy.
9. Installs the selected large spaCy model: English by default, Italian optionally, or both.
10. Stores WordNet, OMW, Punkt, and Punkt-Tab under the virtual environment, so the managed uninstall removes them with the venv.
11. By default, installs JupyterLab, Notebook, and a user-scoped kernel named `emoatlas311-venv`.
12. Runs `pip check`, verifies WordNet and valence resources, and exercises `EmoScores` with each selected spaCy model.

The repository currently declares Python `>=3.8,<3.12`. This installer deliberately standardizes on Python 3.11 because the repository's own Windows installer does the same. On Windows, Python 3.11.9 is the last 3.11 release with official binary installers; later 3.11 security releases are source-only.

## Before installation

1. Use a supported 64-bit Windows version.
2. Install **64-bit Python 3.11.9** from:
   `https://www.python.org/downloads/release/python-3119/`
3. In the Python installer, keep `pip` and the Python launcher enabled. Adding Python to `PATH` is useful but not mandatory when the `py` launcher is present.
4. Ensure several gigabytes of free disk space. Large spaCy models, scientific Python wheels, and Jupyter are substantial.
5. Close old Python/Jupyter sessions that may be holding files open.

You do not need Git, Conda, Miniconda, Visual Studio, or administrator privileges for the normal wheel-based installation.

## Install

Open **Command Prompt** in the folder containing the batch file, then choose one command.

### English model, Jupyter included (default)

```bat
setup_emoatlas_venv.bat
```

### Italian model instead of English

```bat
setup_emoatlas_venv.bat --italian
```

### Both English and Italian models

```bat
setup_emoatlas_venv.bat --both
```

### No Jupyter

```bat
setup_emoatlas_venv.bat --no-jupyter
```

### Install in a custom directory

Set `EMOATLAS_HOME` for that Command Prompt session before running the installer:

```bat
set "EMOATLAS_HOME=D:\Applications\EmoAtlas"
setup_emoatlas_venv.bat --both
```

Use a local fixed drive. Avoid moving the virtual environment afterward; virtual environments contain absolute paths and should be recreated at a new destination rather than copied.

### Pin the EmoAtlas source archive (advanced)

By default, the installer uses the repository’s current `main` branch, matching the update-oriented behavior of the upstream installer. For a reproducible installation, set `EMOATLAS_ZIP_URL` to a GitHub tag or commit archive before running the batch file. Example shape:

```bat
set "EMOATLAS_ZIP_URL=https://github.com/MassimoStel/emoatlas/archive/COMMIT_OR_TAG.zip"
setup_emoatlas_venv.bat --both
```

Record the chosen commit/tag and save a package snapshot afterward:

```bat
"%LOCALAPPDATA%\EmoAtlas\venv\Scripts\python.exe" -m pip freeze > emoatlas-packages.txt
```

## Start and use EmoAtlas

### Activate in Command Prompt

```bat
call "%LOCALAPPDATA%\EmoAtlas\activate_emoatlas.bat"
python
```

Then test:

```python
import emoatlas
print(emoatlas.__version__)
```

Leave the environment with:

```bat
deactivate
```

Activation is convenient but not required. Direct execution is unambiguous:

```bat
"%LOCALAPPDATA%\EmoAtlas\venv\Scripts\python.exe" your_script.py
```

### Start JupyterLab

```bat
"%LOCALAPPDATA%\EmoAtlas\start_emoatlas_jupyterlab.bat"
```

In a notebook, select **Python (EmoAtlas venv 3.11)**.

### Confirm which Python is active

```bat
where python
python -c "import sys; print(sys.executable); print(sys.prefix); print(sys.base_prefix)"
```

Inside the venv, `sys.prefix` should point to the EmoAtlas venv and differ from `sys.base_prefix`.

## Update or repair

Rerun the installer to update packages and reinstall the current GitHub `main` branch:

```bat
setup_emoatlas_venv.bat
```

To discard and rebuild only the managed environment:

```bat
setup_emoatlas_venv.bat --recreate
```

Use the same language option when recreating, for example:

```bat
setup_emoatlas_venv.bat --recreate --both
```

The installer does not pin a permanent snapshot of every transitive dependency because the repository itself does not provide a lock file. For reproducible research, capture a known-good environment after installation:

```bat
"%LOCALAPPDATA%\EmoAtlas\venv\Scripts\python.exe" -m pip freeze > emoatlas-lock.txt
```

## Remove the installation created by this batch file

Run the same batch file from a location **outside** `%LOCALAPPDATA%\EmoAtlas`:

```bat
setup_emoatlas_venv.bat --remove
```

This removes:

- `%LOCALAPPDATA%\EmoAtlas\venv`
- NLTK data stored inside that venv
- the `emoatlas311-venv` Jupyter kernelspec
- the activation and Jupyter launch helpers

It deliberately does not delete unknown files in the home directory and does not touch unrelated Python, Conda, or Jupyter installations.

For a custom home, set exactly the same variable first:

```bat
set "EMOATLAS_HOME=D:\Applications\EmoAtlas"
setup_emoatlas_venv.bat --remove
```

# Thorough removal of older or unrelated EmoAtlas installations

Do not run every deletion command blindly. First identify how EmoAtlas was installed, then remove only that copy. Multiple Python interpreters can each have a separate installation.

## 1. Stop processes and deactivate environments

Close notebooks, Jupyter servers, IDE Python consoles, and terminals using EmoAtlas.

In an activated venv:

```bat
deactivate
```

In Conda:

```bat
conda deactivate
```

Repeat `conda deactivate` until the prompt no longer shows an environment name.

Check for lingering processes in Task Manager and stop only the relevant `python.exe`, `pythonw.exe`, `jupyter.exe`, or `jupyter-lab.exe` processes.

## 2. Inventory all Python interpreters

```bat
where python
where py
py -0p
```

`py -0p` lists Python installations known to the Windows launcher. For each relevant interpreter path, inspect EmoAtlas with that interpreter's own `-m pip`:

```bat
"C:\Path\To\Python\python.exe" -m pip show emoatlas
"C:\Path\To\Python\python.exe" -m pip list | findstr /I "emoatlas"
```

Never rely on a bare `pip` command when cleaning multiple Python installations; it may target a different interpreter than expected.

## 3. Remove an old Conda environment created by the repository batch file

The repository's existing Windows installer creates an environment named `emoatlas311` and registers a kernel with the same name.

Inspect first:

```bat
conda env list
jupyter kernelspec list
```

Remove the environment:

```bat
conda deactivate
conda env remove -n emoatlas311 -y
```

Remove its Jupyter kernel if it remains:

```bat
jupyter kernelspec remove -f emoatlas311
```

Some Jupyter versions accept the synonymous command:

```bat
jupyter kernelspec uninstall -f emoatlas311
```

If `conda` is no longer on `PATH`, run `conda.exe` from the old Anaconda/Miniconda installation or remove the environment directory only after confirming its exact path from historical configuration. Do not delete the whole Anaconda/Miniconda directory merely to remove EmoAtlas unless you intend to uninstall that entire distribution.

## 4. Remove a manually created virtual environment

A virtual environment is normally removed by deleting its directory after deactivation. Common names are `.venv`, `venv`, `env`, or a custom folder.

First verify the candidate directory:

```bat
"C:\Path\To\CandidateVenv\Scripts\python.exe" -c "import sys; print(sys.executable); print(sys.prefix); print(sys.base_prefix)"
"C:\Path\To\CandidateVenv\Scripts\python.exe" -m pip show emoatlas
```

Then close anything using it and delete only that venv directory:

```bat
rmdir /S /Q "C:\Path\To\CandidateVenv"
```

Also remove any Jupyter kernel that points to it; see section 7.

## 5. Remove a global or per-user pip installation

For every interpreter where `pip show emoatlas` succeeds:

```bat
"C:\Path\To\Python\python.exe" -m pip uninstall -y emoatlas
```

Verify:

```bat
"C:\Path\To\Python\python.exe" -c "import importlib.util; print(importlib.util.find_spec('emoatlas'))"
```

The expected result is `None` for that interpreter.

Do **not** automatically uninstall shared libraries such as NumPy, pandas, spaCy, matplotlib, NetworkX, NLTK, SciPy, Shapely, or Jupyter. Other projects may use them. Remove shared dependencies only after checking ownership and usage.

The spaCy models are also installed as Python packages. Remove one only from the specific interpreter and only when it is not used elsewhere:

```bat
"C:\Path\To\Python\python.exe" -m pip uninstall -y en-core-web-lg
"C:\Path\To\Python\python.exe" -m pip uninstall -y it-core-news-lg
```

## 6. Remove editable installs and source clones

An editable installation may point from `site-packages` to a source checkout. Inspect it:

```bat
"C:\Path\To\Python\python.exe" -m pip show -f emoatlas
```

Uninstall it with that interpreter:

```bat
"C:\Path\To\Python\python.exe" -m pip uninstall -y emoatlas
```

Then delete the cloned repository only when it contains no work you need:

```bat
rmdir /S /Q "C:\Path\To\emoatlas"
```

Check for your own notebooks, datasets, modified source, exported charts, and uncommitted Git changes before deleting a clone.

## 7. Remove stale Jupyter kernels

List all kernels and their paths:

```bat
jupyter kernelspec list
```

Common EmoAtlas names are:

- `emoatlas311` — repository Conda installer
- `emoatlas311-venv` — installer supplied here
- any custom name used with `ipykernel install --name`

Remove the exact stale name:

```bat
jupyter kernelspec remove -f KERNEL_NAME
```

A per-user kernelspec usually lives under:

```text
%APPDATA%\jupyter\kernels\KERNEL_NAME
```

If the Jupyter command is unavailable, inspect `kernel.json` before manual deletion. Confirm that its `argv` points to the obsolete Python executable, then remove only that kernel directory:

```bat
rmdir /S /Q "%APPDATA%\jupyter\kernels\KERNEL_NAME"
```

Also check kernels exposed by other Jupyter installations; run `jupyter kernelspec list` from each relevant environment if necessary.

## 8. Remove old NLTK data cautiously

The supplied installer stores NLTK data under its venv, so `--remove` deletes it automatically. Older installations may have downloaded shared data to:

```text
%USERPROFILE%\nltk_data
%APPDATA%\nltk_data
%LOCALAPPDATA%\nltk_data
```

Inspect before deleting. Shared NLTK data may be used by unrelated projects. To see the search path for a particular interpreter:

```bat
"C:\Path\To\Python\python.exe" -c "import nltk; print(*nltk.data.path, sep='\n')"
```

Delete an entire NLTK data directory only when it was dedicated to EmoAtlas. Otherwise remove nothing, or selectively remove resources only after confirming they are not needed (`wordnet`, `omw-1.4`, `punkt`, `punkt_tab`).

## 9. Inspect environment variables and PATH

Open **System Properties → Environment Variables** and inspect user/system values for obsolete entries involving:

- an old EmoAtlas venv `Scripts` directory
- an old Anaconda/Miniconda directory
- `PYTHONPATH`
- `PYTHONHOME`
- `JUPYTER_PATH`
- `NLTK_DATA`

Remove an entry only when it points to the obsolete installation. Do not remove normal Python or Conda entries that are still used.

In the current Command Prompt, inspect resolved executables:

```bat
where python
where pip
where jupyter
```

Open a new Command Prompt after changing environment variables.

## 10. Optional cache cleanup

A pip download cache is not an installation. Purging it can recover disk space but forces future downloads:

```bat
py -3.11 -m pip cache dir
py -3.11 -m pip cache purge
```

Conda package caches are also shared. Clean them only when you understand the impact:

```bat
conda clean --all
```

Review Conda's prompt rather than adding `-y` automatically.

## 11. Final verification after cleanup

Run the checks relevant to the installation method:

```bat
py -0p
where python
where pip
where jupyter
jupyter kernelspec list
conda env list
```

For each remaining Python interpreter:

```bat
"C:\Path\To\Python\python.exe" -c "import importlib.util; print(importlib.util.find_spec('emoatlas'))"
"C:\Path\To\Python\python.exe" -m pip show emoatlas
```

A completely removed copy yields `None` from `find_spec` and “Package(s) not found” from `pip show` for that interpreter. A Jupyter notebook can still import an old copy when its kernel points to another interpreter, which is why kernelspec inspection is essential.

## Troubleshooting installation

### “Python 3.11 was not found”

Install 64-bit Python 3.11.9 with the launcher and pip. Confirm:

```bat
py -3.11 -c "import sys; print(sys.executable, sys.version)"
```

### Access denied or files in use

Close Jupyter, VS Code, PyCharm, notebooks, terminals, and Python processes using the venv. Antivirus can briefly lock newly installed executables; retry after the scan completes.

### Download or TLS errors

The installer needs HTTPS access to PyPI, GitHub, spaCy model hosting, and NLTK data hosting. In an organizational network, configure the approved proxy/certificate chain rather than disabling TLS verification.

### Microsoft Visual C++ build errors

The installer requests binary wheels where possible. A compiler prompt often means a compatible wheel was unavailable, the interpreter is not normal 64-bit CPython 3.11, or the package index/proxy served an incomplete set. Confirm architecture:

```bat
py -3.11 -c "import platform,sys; print(platform.architecture()); print(sys.executable)"
```

### `ModuleNotFoundError: emoatlas` in a notebook

The notebook is probably using a different kernel. Select **Python (EmoAtlas venv 3.11)** and verify:

```python
import sys
print(sys.executable)
```

It should point to `%LOCALAPPDATA%\EmoAtlas\venv\Scripts\python.exe` (or your custom home).

### Rebuild after a partially failed installation

```bat
setup_emoatlas_venv.bat --recreate
```

Use `--no-pause` when calling the batch file from another script or CI job so its exit code can be consumed without a keypress.

## Design notes

- The installer invokes the venv's Python explicitly instead of relying on activation, preventing accidental package installation into the wrong interpreter.
- It downloads a ZIP rather than running `pip install git+...`, eliminating Git as an installation prerequisite.
- The source ZIP is temporary and deleted after installation.
- The script patches only two repository packaging details in that temporary copy: the incorrect bare `community` requirement and the omitted `valence/*` package-data pattern. It retains `python-louvain`, verifies `community.community_louvain`, loads English and Italian valence resources, and exercises `EmoScores`.
- `simplemma` is installed because the EmoAtlas source uses it for Italian lemma repair and the README recommends it for Italian workflows.
- `punkt` and `punkt_tab` are included in addition to WordNet/OMW because the source can call NLTK tokenization in its Snowball stemming path.
- The old installer's unconditional `tokenizers` repair is not carried over: EmoAtlas's declared/runtime imports do not require Hugging Face `tokenizers`. A clean isolated venv avoids repairing unrelated packages, and `pip check` catches actual inconsistencies.
- No system-wide package uninstall is automated. Historical installations require identification because deleting the wrong interpreter, environment, kernelspec, or shared data directory can damage unrelated projects.

## Limitations

The batch file was statically checked for labels, line endings, command structure, and repository-aligned dependencies in a Linux build environment. It could not be executed under native Windows `cmd.exe` here. Package indexes and the GitHub `main` branch can change after this guide was produced; retain a `pip freeze` lock file for research reproducibility.
